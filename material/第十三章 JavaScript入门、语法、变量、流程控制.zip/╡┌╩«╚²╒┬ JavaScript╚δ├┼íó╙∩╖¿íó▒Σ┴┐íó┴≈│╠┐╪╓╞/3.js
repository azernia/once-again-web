document.getElementById('btn').onclick=function(){
	alert(1);
}
 